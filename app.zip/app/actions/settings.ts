"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import { writeAudit } from "@/lib/audit";

const GTM_RE      = /^GTM-[A-Z0-9]{4,10}$/;
const FB_PIXEL_RE = /^\d{10,20}$/;

const ALLOWED_KEYS = new Set([
  "phone", "whatsapp", "email", "address",
  "instagram", "facebook",
  "hero_title", "hero_subtitle",
  "meta_title", "meta_description",
  "gtm_id", "facebook_pixel_id",
]);
const URL_MAX = 300;
const TEXT_MAX = 500;

function sanitizeText(value: unknown, max = TEXT_MAX): string {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

function sanitizeUrl(value: unknown): string {
  const s = sanitizeText(value, URL_MAX);
  if (!s) return "";
  try {
    const u = new URL(s);
    if (u.protocol !== "https:" && u.protocol !== "http:") return "";
    return s;
  } catch {
    return "";
  }
}

function sanitizePhone(value: unknown): string {
  const s = sanitizeText(value, 30);
  // Allow digits, spaces, +, -, (, )
  return s.replace(/[^\d\s+\-().]/g, "");
}

function sanitizeEmail(value: unknown): string {
  const s = sanitizeText(value, 200);
  // Basic email shape check
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s) ? s : "";
}

function sanitizeGtm(value: unknown): string {
  const s = sanitizeText(value, 20);
  if (!s) return "";
  return GTM_RE.test(s) ? s : "";
}

export async function saveSetting(key: string, value: string) {
  const session = await requireSession();
  if (!ALLOWED_KEYS.has(key)) throw new Error("Clé de paramètre invalide");
  const sanitized = sanitizeText(value);
  await db.siteSetting.upsert({
    where: { key },
    update: { value: sanitized },
    create: { key, value: sanitized },
  });
  await writeAudit(session, "update", "SiteSetting", key);
  revalidatePath("/admin/settings");
  revalidatePath("/");
}

export async function saveSettings(_: unknown, formData: FormData): Promise<{ success: boolean; errors?: Record<string, string> }> {
  const session = await requireSession();

  const gtmRaw = sanitizeGtm(formData.get("gtm_id"));
  const gtmInput = sanitizeText(formData.get("gtm_id"), 20);

  const fbPixelRaw = sanitizeText(formData.get("facebook_pixel_id"), 20).replace(/\s/g, "");
  const fbPixelInput = fbPixelRaw;

  const errors: Record<string, string> = {};
  if (gtmInput && !gtmRaw) errors.gtm_id = "Format invalide. Exemple : GTM-XXXXXXX";
  if (fbPixelInput && !FB_PIXEL_RE.test(fbPixelInput)) errors.facebook_pixel_id = "Format invalide. Le Pixel ID est un nombre de 10 à 20 chiffres.";
  if (Object.keys(errors).length > 0) return { success: false, errors };

  const fieldMap: Record<string, string> = {
    phone:              sanitizePhone(formData.get("phone")),
    whatsapp:           sanitizePhone(formData.get("whatsapp")),
    email:              sanitizeEmail(formData.get("email")),
    address:            sanitizeText(formData.get("address"), 300),
    instagram:          sanitizeUrl(formData.get("instagram")),
    facebook:           sanitizeUrl(formData.get("facebook")),
    hero_title:         sanitizeText(formData.get("hero_title")),
    hero_subtitle:      sanitizeText(formData.get("hero_subtitle")),
    meta_title:         sanitizeText(formData.get("meta_title"), 100),
    meta_description:   sanitizeText(formData.get("meta_description"), 300),
    gtm_id:             gtmRaw,
    facebook_pixel_id:  FB_PIXEL_RE.test(fbPixelInput) ? fbPixelInput : "",
  };

  await Promise.all(
    Object.entries(fieldMap).map(([key, value]) =>
      db.siteSetting.upsert({
        where: { key },
        update: { value },
        create: { key, value },
      })
    )
  );

  await writeAudit(session, "update", "SiteSettings", "Paramètres du site");
  revalidatePath("/admin/settings");
  revalidatePath("/");
  return { success: true };
}
